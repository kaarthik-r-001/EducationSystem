package com.teamThree.springsecurityclient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringsecurityclientApplicationTests {

	@Test
	void contextLoads() {
	}

}
