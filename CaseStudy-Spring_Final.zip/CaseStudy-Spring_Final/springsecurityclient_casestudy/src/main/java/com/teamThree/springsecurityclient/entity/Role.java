package com.teamThree.springsecurityclient.entity;

public enum Role {
	ADMIN,
	USER
}
