package com.teamThree.springsecurityclient.repository;

import com.teamThree.springsecurityclient.entity.CourseAssignment;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CourseAssignmentRepository extends JpaRepository<CourseAssignment,Long> {
}
