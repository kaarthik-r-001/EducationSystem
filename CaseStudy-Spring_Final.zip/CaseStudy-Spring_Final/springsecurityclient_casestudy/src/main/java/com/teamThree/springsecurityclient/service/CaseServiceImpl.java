package com.teamThree.springsecurityclient.service;

import com.teamThree.springsecurityclient.entity.Course;
import com.teamThree.springsecurityclient.entity.Student;
import com.teamThree.springsecurityclient.repository.CourseRepository;
import com.teamThree.springsecurityclient.repository.StudentRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Objects;

@Service
public class CaseServiceImpl implements CaseService {


    
    @Autowired
    private StudentRepository studentRepository;
    @Autowired
    private CourseRepository courseRepository;



    private final Logger logger = LoggerFactory.getLogger(CaseServiceImpl.class);
    @Override
    public Student saveStudents(Student student) {
        logger.info("adding new student");
        return studentRepository.save(student);
    }
    @Override
    public Student getStudentById(Long studentId){
        logger.info("getting student by id");
        return studentRepository.findById(studentId).get();
    }
    public Student updateStudent(Long studentId,Student student){
        Student studentDB=studentRepository.findById(studentId).get();
        logger.info("updating student");

        if(Objects.nonNull(student.getFirstName()) && !"".equalsIgnoreCase(student.getFirstName())){
            studentDB.setFirstName(student.getFirstName());

        }
        if(Objects.nonNull(student.getLastName()) && !"".equalsIgnoreCase(student.getLastName())){
            studentDB.setLastName(student.getLastName());

        }
        if(Objects.nonNull(student.getDateOfBirth()) && !"".equalsIgnoreCase(student.getDateOfBirth().toString())){
            studentDB.setDateOfBirth(student.getDateOfBirth());

        }
        if(Objects.nonNull(student.getEmail()) && !"".equalsIgnoreCase(student.getEmail())){
            studentDB.setEmail(student.getEmail());

        }
        if(Objects.nonNull(student.getEnrollmentDate()) && !"".equalsIgnoreCase(student.getEnrollmentDate().toString())){
            studentDB.setEnrollmentDate(student.getEnrollmentDate());

        }

        return studentRepository.save(studentDB);
    }


    public void deleteStudentsById(Long studentId) {
        logger.info("deleting student")

        studentRepository.deleteById(studentId);

    }

    @Override
    public List getAllStudents() {
        logger.info("returning all students");

        return studentRepository.findAll();
    }

    @Override
    public Course saveCourses(Course course) {
        logger.info("saving the course");
        return courseRepository.save(course);
    }

    @Override
    public Course getCourseById(Long courseId) {
        logger.info("getting course by id");
        return courseRepository.findById(courseId).get();
    }

    @Override
    public Course updateCourse(Long courseId, Course course) {
        logger.info("updaitng the course details");
        Course courseDB=courseRepository.findById(courseId).get();
        if(Objects.nonNull(course.getCourseName()) && !"".equalsIgnoreCase(course.getCourseName())){
            courseDB.setCourseName(course.getCourseName());
        }
        if(Objects.nonNull(course.getCredits()) && !"".equalsIgnoreCase(course.getCredits().toString())){
            courseDB.setCredits(course.getCredits());
        }
        return courseRepository.save(courseDB);
    }

    @Override
    public void deleteCoursesById(Long courseId) {
        logger.info("deleting the course");
        courseRepository.deleteById(courseId);
    }

    @Override
    public List getAllCourses() {
        logger.info("selecting all the courses");
        return courseRepository.findAll();
    }


}
