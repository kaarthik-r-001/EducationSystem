package com.teamThree.springsecurityclient.service;

import com.teamThree.springsecurityclient.entity.Course;
import com.teamThree.springsecurityclient.entity.Student;

import java.util.List;

public interface CaseService {
    Student saveStudents(Student student);

    Student getStudentById(Long studentId);

    Student updateStudent(Long studentId, Student department);

    void deleteStudentsById(Long studentId);

    List getAllStudents();

    Course saveCourses(Course course);

    Course getCourseById(Long courseId);

    Course updateCourse(Long courseId, Course course);

    void deleteCoursesById(Long courseId);

    List getAllCourses();

}
