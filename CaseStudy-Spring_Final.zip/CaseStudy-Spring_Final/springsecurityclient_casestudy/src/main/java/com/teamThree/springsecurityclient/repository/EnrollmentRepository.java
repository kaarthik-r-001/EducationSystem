package com.teamThree.springsecurityclient.repository;

import com.teamThree.springsecurityclient.entity.Enrollment;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EnrollmentRepository extends JpaRepository<Enrollment,Long> {
}
