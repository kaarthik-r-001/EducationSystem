package com.teamThree.springsecurityclient.controller;

import com.teamThree.springsecurityclient.entity.Course;
import com.teamThree.springsecurityclient.entity.Student;
import com.teamThree.springsecurityclient.service.CaseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController
@RequestMapping("api/v1")
public class CaseController {
    @Autowired

    private CaseService caseService;
    // localhost:8080/departments
    @PostMapping("/student")
    public Student saveStudents(@RequestBody Student student){
        return caseService.saveStudents(student);
    }

    @GetMapping("/student/{id}")
    public Student getStudentById(@PathVariable("id") Long studentId){
        return caseService.getStudentById(studentId);
    }
    @PutMapping("/student/{id}")
    public Student updateStudent(@PathVariable("id") Long studentId,@RequestBody Student department){
        return caseService.updateStudent(studentId,department);
    }
    @DeleteMapping("/student/{id}")
    public String deleteStudent(@PathVariable("id") Long studentId){
        caseService.deleteStudentsById(studentId);
        return "Student deleted Successfully!";
    }
    @GetMapping("/student/all")
    public List getAllStudents(){
        return caseService.getAllStudents();
    }



    @PostMapping("/course")
    public Course saveCourses(@RequestBody Course course){
        return caseService.saveCourses(course);
    }

    @GetMapping("/course/{id}")
    public Course getCourseById(@PathVariable("id") Long courseId){
        return caseService.getCourseById(courseId);
    }
    @PutMapping("/course/{id}")
    public Course updateCourse(@PathVariable("id") Long courseId,@RequestBody Course course){
        return caseService.updateCourse(courseId,course);
    }
    @DeleteMapping("/course/{id}")
    public String deleteCourse(@PathVariable("id") Long courseId){
        caseService.deleteCoursesById(courseId);
        return "Course deleted Successfully!";
    }
    @GetMapping("/course/all")
    public List getAllCourses(){
        return caseService.getAllCourses();
    }
}
